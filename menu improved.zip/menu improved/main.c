#include "backround.h"
int main(int argc,char *argv[]){
int running=1,but1,logoframe=0,optmode,cox,coy,fs=0;
SDL_Surface *screen;
SDL_Event event,optevent;
int y,x,cx,cy;
Uint8 volume=MIX_MAX_VOLUME/2;

SDL_Init(SDL_INIT_EVERYTHING );
Mix_OpenAudio(44100, AUDIO_S16SYS ,2,1024);
Mix_Chunk *son;
Mix_Music *bgm= Mix_LoadMUS("bgm.mp3");
son= Mix_LoadWAV("ping.wav");
Mix_PlayMusic(bgm,-1);
Mix_VolumeMusic(volume);
Mix_VolumeChunk(son,volume);
initsurfaces();
screen=SDL_SetVideoMode(800,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
while(running){
logoframe++;
if(logoframe>2){
logoframe=0;}
while(SDL_PollEvent(&event)){
        switch(event.type)
        {
            case SDL_QUIT:
            running=0;
            break;
case SDL_MOUSEMOTION:
x=event.motion.x;
y=event.motion.y;

break;
 case SDL_KEYDOWN :
switch(event.key.keysym.sym){
case SDLK_ESCAPE :
running=0;
break;
case SDLK_o :
optmode=1;
break;


}//key
case SDL_MOUSEBUTTONUP:
if (event.button.button == SDL_BUTTON_LEFT){
cx=event.button.x; 
cy=event.button.y;}
break;
        }//eventtype

}//poll

if(x>posplaybut.x&& x<posplaybut.x+posplaybut.w && y>posplaybut.y && y<posplaybut.y+posplaybut.h){
blitterplay2(screen);
Mix_PlayChannel(1,son, 0);
SDL_Delay(150);

}
if(x>pos_loadbut.x&& x<pos_loadbut.x+posplaybut.w && y>pos_loadbut.y && y<pos_loadbut.y+posplaybut.h){

blitterload2(screen);
SDL_Delay(150);
Mix_PlayChannel(1,son,0);
 }      

if(x>pos_optbut.x&& x<pos_optbut.x+posplaybut.w && y>pos_optbut.y && y<pos_optbut.y+posplaybut.h){
blitteropt2(screen);
SDL_Delay(150);
Mix_PlayChannel(1,son,0);
 }      
if(x>pos_quitbut.x&& x<pos_quitbut.x+posplaybut.w && y>pos_quitbut.y && y<pos_quitbut.y+posplaybut.h){
blitterquit2(screen);
SDL_Delay(150);
Mix_PlayChannel(1,son,0);
 }      
if(logoframe==0){
blitlogo2(screen);
}//logo anim


blitter(screen);
if(cx>pos_quitbut.x&& cx<pos_quitbut.x+posplaybut.w && cy>pos_quitbut.y && cy<pos_quitbut.y+posplaybut.h){
running=0;}//quit button
if(cx>pos_optbut.x&& cx<pos_optbut.x+posplaybut.w && cy>pos_optbut.y && cy<pos_optbut.y+posplaybut.h){
optmode=1;}
while(optmode==1){
blitoptmenu(screen);
while(SDL_PollEvent(&optevent)){
        switch(optevent.type)
        {
case SDL_KEYDOWN ://opt loop exit
switch(optevent.key.keysym.sym){
case SDLK_ESCAPE :
optmode=0;
break;
case SDLK_KP_MINUS:
volume=volume-20;
if(volume<20){
volume=0;}
Mix_VolumeMusic(volume);
Mix_VolumeChunk(son,volume);
break;
case SDLK_KP_PLUS : 
volume=volume+20;
Mix_VolumeMusic(volume);
Mix_VolumeChunk(son,volume);
break;
case SDLK_f ://fullscreeen
if(fs==0){ 
screen=SDL_SetVideoMode(1536,844,32,SDL_HWSURFACE|SDL_FULLSCREEN);

blitter(screen);
fs=1;}
else if(fs==1){
screen=SDL_SetVideoMode(800,600,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
blitter(screen);
fs=0;
}
break;

}
case SDL_MOUSEBUTTONUP:
if (event.button.button == SDL_BUTTON_LEFT){
cx=optevent.button.x; 
cy=optevent.button.y;
 if(optevent.button.x>440 && optevent.button.x<600 && optevent.button.y>250 && optevent.button.y<270){ //volume down
volume=volume-20;
if(volume<20){
volume=0;}
Mix_VolumeMusic(volume);
Mix_VolumeChunk(son,volume);
Mix_PlayChannel(1,son,0);
}
if(optevent.button.x>440 && optevent.button.x<600 && optevent.button.y>285 && optevent.button.y<310){ //volume up
volume=volume+20;
Mix_VolumeMusic(volume);
Mix_VolumeChunk(son,volume);
Mix_PlayChannel(1,son,0);
}

break;




}
}//type
}//poll

if(cx>412 && cx<440 && cy>207 && cy<234){
optmode=0;}



}//optloop

}//game loop
SDL_FreeSurface(screen);
SDL_FreeSurface(logo);
SDL_FreeSurface(loadbut);
SDL_FreeSurface(back);
SDL_FreeSurface(playbut);
SDL_FreeSurface(quitbut);
SDL_FreeSurface(optbut);
SDL_FreeSurface(logo2);
Mix_FreeMusic(bgm);
SDL_FreeSurface(quitbutt2);
SDL_FreeSurface(loadbut2);
SDL_FreeSurface(optbutt2);
SDL_FreeSurface(optmenu);









Mix_Quit();
SDL_Quit();

return EXIT_SUCCESS;
}
