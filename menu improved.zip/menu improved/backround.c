#include "backround.h"


void initsurfaces(){
poslogo.x=190;
poslogo.y=10;
posback.x=0;
posback.y=0;
posplaybut.x=0;
posplaybut.y=200;
pos_loadbut.x=5;
pos_loadbut.y=280;
pos_optbut.x=5;
pos_optbut.y=360;
pos_quitbut.x=0;
pos_quitbut.y=440;

logo=IMG_Load("logo.png");
back=IMG_Load("background.png");
playbut=IMG_Load("playbut.png");
loadbut=IMG_Load("loadbut.png");
optbut=IMG_Load("optbut.png");
quitbut=IMG_Load("quit.but.png");


}
void blitter(SDL_Surface* screen)
{

    


 SDL_FillRect(screen,NULL,SDL_MapRGB(screen->format,0,0,0));
SDL_BlitSurface(back,NULL,screen,&posback);
 SDL_BlitSurface(logo,NULL,screen,&poslogo);
SDL_BlitSurface(playbut,NULL,screen,&posplaybut);
 SDL_BlitSurface(loadbut,NULL,screen,&pos_loadbut);
 SDL_BlitSurface(optbut,NULL,screen,&pos_optbut);
 SDL_BlitSurface(quitbut,NULL,screen,&pos_quitbut);
SDL_Flip(screen);





}


void blitterplay2(SDL_Surface* screen){

SDL_Surface *playbut2=NULL;
    

posplaybut2.x=0;
posplaybut2.y=200;


playbut2=IMG_Load("playbut2.png");



SDL_BlitSurface(playbut2,NULL,screen,&posplaybut2);
 SDL_Flip(screen);




}





void blitterload2(SDL_Surface *screen){

pos_loadbut2.x=0;
pos_loadbut2.y=280;


loadbut2=IMG_Load("loadbut2.png");



SDL_BlitSurface(loadbut2,NULL,screen,&pos_loadbut2);
 
SDL_Flip(screen);



}


void blitteropt2(SDL_Surface *screen){
pos_optbut2.x=0;
pos_optbut2.y=360;


optbutt2=IMG_Load("optbut2.png");



SDL_BlitSurface(optbutt2,NULL,screen,&pos_optbut2);
 SDL_Flip(screen);


}

void blitterquit2(SDL_Surface *screen){
pos_quitbut2.x=0;
pos_quitbut2.y=440;


quitbutt2=IMG_Load("quitbut2.png");



SDL_BlitSurface(quitbutt2,NULL,screen,&pos_quitbut2);
SDL_Flip(screen);




}
void blitlogo2(SDL_Surface *screen){
pos_logo2.x=190;
pos_logo2.y=5;
logo2=IMG_Load("logo2.png");
 SDL_BlitSurface(logo2,NULL,screen,&pos_logo2);
SDL_Flip(screen);

}

void blitoptmenu(SDL_Surface *screen){
posoptmenu.x=400;
posoptmenu.y=200;
optmenu=IMG_Load("optmenu.png");
 SDL_BlitSurface(optmenu,NULL,screen,&posoptmenu);
SDL_Flip(screen);

}



