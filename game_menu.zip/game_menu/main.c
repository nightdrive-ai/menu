#include <stdio.h>
#include <stdlib.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>



int main(int argc,char *argv[]){
SDL_Surface *screen=NULL,*game=NULL;
SDL_Surface *menu=NULL,*button=NULL,*button2=NULL,*button3=NULL,*inf=NULL,*texte=NULL,*button4=NULL,*button1a=NULL,*button2a=NULL,*button3a=NULL,*button4a=NULL,*optmenu=NULL,*sprite=NULL,*team=NULL;
int running=1,options=0,fs=0,an=1;
SDL_Rect posmenu,posbutton,posbutton2,posbutton3,posplay,posinf,postxt,posbutton4,positionClic,posa1,posa2,posa3,posa4,posopt,frame,possprite,posteam;
SDL_Event event,optevent;
int curframe=0;
int maxframe=3;
Uint8 volume = 128;



possprite.x=300;
possprite.y=0;
frame.h=48;
frame.w=32;
frame.x=0;
frame.y=0;
SDL_Color couleurNoire={0,0,0},couleurBlanche ={255,255,255};





 // intialisation police 










SDL_Init(SDL_INIT_EVERYTHING );
TTF_Init();
TTF_Font *policeBig =NULL;
Mix_OpenAudio(44100, AUDIO_S16SYS ,2,1024);
Mix_Music *bgm= Mix_LoadMUS("bgm.mp3");
Mix_Chunk *son;
son= Mix_LoadWAV("ping.wav");
policeBig=TTF_OpenFont("times.ttf",50);//grande police

team=TTF_RenderText_Blended(policeBig,"Brainstorm",couleurBlanche);
posteam.x=0;
posteam.y=0;


screen=SDL_SetVideoMode(1080,1080,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
game=SDL_SetVideoMode(1080,1080,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
SDL_WM_SetCaption("Infiltrator",NULL);
Mix_PlayMusic(bgm,-1);
Mix_VolumeMusic(volume);
menu=IMG_Load("menu.jpg");
button1a=IMG_Load("button1a.png");
button2a=IMG_Load("button2a.png");
button3a=IMG_Load("button3a.png");
button4a=IMG_Load("button4a.png");
button=IMG_Load("button.png");
button2=IMG_Load("button2.png");
button3=IMG_Load("button3.png");
button4=IMG_Load("button4.png");
optmenu=IMG_Load("optmenu.png");
sprite=IMG_Load("sprite.png");
inf=IMG_Load("inf.png");
posmenu.x=0;
posmenu.y=0;
posbutton.x=300;
posbutton.y=0;
posbutton2.x=300;
posbutton2.y=0;
posbutton3.x=300;
posbutton3.y=0;
posbutton4.x=300;
posbutton4.y=0;
posinf.x=450;
posinf.y=0;
posa1.x=300;
posa1.y=0;
posa2.x=300;
posa2.y=0;
posa3.x=300;
posa3.y=0;
posa4.x=300;
posa4.y=0;
posinf.x=450;
posinf.y=0;
posopt.x=300;
posopt.y=300;








while(running){


SDL_BlitSurface(sprite,&frame,screen,&possprite);
curframe +=1;
if(curframe>maxframe){
curframe=0;}
frame.x=curframe*frame.w;
SDL_Delay(100);

while(SDL_PollEvent(&event)){
switch(event.type){
case SDL_QUIT :
running=0;
break;
case SDL_KEYDOWN :
switch(event.key.keysym.sym){
case SDLK_ESCAPE :
running=0;
break;
//here
}
case SDL_MOUSEBUTTONUP:
if (event.button.button == SDL_BUTTON_LEFT){
positionClic.x=event.button.x; 
positionClic.y=event.button.y;

 if (event.button.x>298 && event.button.x<793 && event.button.y>466 && event.button.y<526) 
{
exit(0);
}
else if (event.button.x>298 && event.button.x<793 && event.button.y>386 && event.button.y<445){
options=1;}

while(options==1){

SDL_BlitSurface(optmenu,NULL,screen,&posopt);
SDL_Flip(screen);
SDL_Delay(50);





while(SDL_PollEvent(&optevent)){
switch(optevent.type){
case SDL_MOUSEBUTTONUP:
if (optevent.button.button == SDL_BUTTON_LEFT){

if (optevent.button.x>503 && optevent.button.x<612 && optevent.button.y>521 && optevent.button.y<554){ 
options=0;}
else if(optevent.button.x>524 && optevent.button.x<589 && optevent.button.y>391 && optevent.button.y<450){ 
volume=volume-20;
Mix_VolumeMusic(volume);}
else if(optevent.button.x>394 && optevent.button.x<458 && optevent.button.y>391 && optevent.button.y<450){ 
volume=volume+20;
Mix_VolumeMusic(volume);}
else if(optevent.button.x>655 && optevent.button.x<721 && optevent.button.y>391 && optevent.button.y<450){
if(fs==0){ 
screen=SDL_SetVideoMode(1536,844,32,SDL_HWSURFACE|SDL_FULLSCREEN);
SDL_Flip(screen);
fs=1;
}
else if(fs==1){
screen=SDL_SetVideoMode(1080,1080,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
SDL_Flip(screen);
fs=0;



}
}



}}

}}}
break;
case SDL_MOUSEMOTION:
if(event.motion.x>298 && event.motion.x<793 && event.motion.y>225 && event.motion.y<280){
texte=TTF_RenderText_Blended(policeBig,"Start a new game",couleurBlanche);
Mix_PlayChannel(1,son, 0);

postxt.x=0;
postxt.y=800;
SDL_BlitSurface(texte,NULL,screen,&postxt);
SDL_BlitSurface(button1a,NULL,screen,&posa1);
SDL_Flip(screen);

SDL_Delay(50);




}
 else if (event.motion.x>298 && event.motion.x<793 && event.motion.y>466 && event.motion.y<526){
texte=TTF_RenderText_Blended(policeBig,"Quit to Desktop",couleurBlanche);
postxt.x=0;
postxt.y=800;
Mix_PlayChannel(1,son, 0);
SDL_BlitSurface(texte,NULL,screen,&postxt);
SDL_BlitSurface(button4a,NULL,screen,&posa4);
SDL_Flip(screen);
SDL_Delay(50);
}
else if(event.motion.x>298 && event.motion.x<793 && event.motion.y>304 && event.motion.y<366){

texte=TTF_RenderText_Blended(policeBig,"Load a saved game",couleurBlanche);
postxt.x=0;
postxt.y=800;

Mix_PlayChannel(1,son, 0);
SDL_BlitSurface(texte,NULL,screen,&postxt);
SDL_BlitSurface(button2a,NULL,screen,&posa2);
SDL_Flip(screen);
SDL_Delay(50);
}
else if (event.motion.x>298 && event.motion.x<793 && event.motion.y>386 && event.motion.y<445){

texte=TTF_RenderText_Blended(policeBig,"Customize video/audio",couleurBlanche);
postxt.x=0;
postxt.y=800;

Mix_PlayChannel(1,son, 0);
SDL_BlitSurface(texte,NULL,screen,&postxt);
SDL_BlitSurface(button3a,NULL,screen,&posa3);
SDL_Flip(screen);
SDL_Delay(50);
}






}




SDL_BlitSurface(menu,NULL,screen,&posmenu);
SDL_BlitSurface(button,NULL,screen,&posbutton);
SDL_BlitSurface(button2,NULL,screen,&posbutton2);
SDL_BlitSurface(button3,NULL,screen,&posbutton3);
SDL_BlitSurface(button4,NULL,screen,&posbutton4);
SDL_BlitSurface(inf,NULL,screen,&posinf);



}

SDL_BlitSurface(team,NULL,screen,&posteam);
SDL_Flip(screen);


}

SDL_FreeSurface(button);
SDL_FreeSurface(button2);
SDL_FreeSurface(button3);
SDL_FreeSurface(button4);
SDL_FreeSurface(menu);
SDL_FreeSurface(inf);
Mix_FreeMusic(bgm);
Mix_FreeChunk(son);
SDL_FreeSurface(texte);
SDL_FreeSurface(button1a);
SDL_FreeSurface(button2a);
SDL_FreeSurface(button3a);
SDL_FreeSurface(button4a);
SDL_FreeSurface(screen);
SDL_FreeSurface(optmenu);
SDL_FreeSurface(sprite);
SDL_FreeSurface(team);
TTF_CloseFont(policeBig);
TTF_Quit(); 

Mix_Quit();
SDL_Quit();
return EXIT_SUCCESS;

}
