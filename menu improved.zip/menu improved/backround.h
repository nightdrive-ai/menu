#ifndef BACKROUND_H_INCLUDED
#define BACKROUND_H_INCLUDED
 
#include <stdio.h>
#include <stdlib.h>
#include<SDL/SDL_ttf.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_mixer.h>
SDL_Rect posplaybut2,posplaybut,pos_optbut,pos_loadbut,pos_quitbut,pos_optbut2,pos_loadbut2,pos_quitbut2,pos_logo2 ,poslogo,posback,posplaybut2,posoptmenu,posback2;
SDL_Surface *loadbut,*optbut,*quitbut,*loadbut2,*optbutt2,*quitbutt2,*logo2,*logo,*back,*playbut,*optmenu,*f_back;

void initsurfaces();
void blitter(SDL_Surface *screen);
void blitterplay2(SDL_Surface *screen);
void blitterload2(SDL_Surface *screen);
void blitteropt2(SDL_Surface *screen);
void blitterquit2(SDL_Surface *screen);
void blitlogo2(SDL_Surface *screen);
void blitoptmenu(SDL_Surface *screen);
//pos















#endif //BACKROUND_H_INCLUDED
